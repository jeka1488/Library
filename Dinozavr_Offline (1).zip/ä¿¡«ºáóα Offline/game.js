var cvs = document.getElementById("canvas");
var ctx = cvs.getContext("2d");

var dino_left_day = new Image();
var dino_left_night = new Image();
var dino_right_day = new Image();
var dino_right_night = new Image();
var bg_day = new Image();
var bg_night = new Image();
var kaktus_day = new Image();
var kaktus_night = new Image();
var oblako_day = new Image();
var oblako_night = new Image();
var ttt = new Image();

dino_left_day.src = "img/dino_left_day.png";
bg_day.src = "img/bg_day.png";
bg_night.src = "img/bg_night.png";
dino_right_day.src = "img/dino_right_day.png";
dino_left_night.src = "img/dino_left_night.png";
dino_right_night.src = "img/dino_right_night.png";
kaktus_night.src = "img/kaktus_night.png";
kaktus_day.src = "img/kaktus_day.png";
oblako_day.src = "img/oblako_day.png";
oblako_night.src = "img/oblako_night.png";
ttt.src = "img/ttt.png";

//Прыжок
document.addEventListener("keydown", moveUp);
function moveUp(){
    if (yPos >= 570)
        yPos -= 300;
}

//Кактусы
var kaktus = [];

kaktus[0] = {
    x : cvs.width,
    y : 570
}

//Облака
var oblako = [];

oblako[0] = {
    x : cvs.width,
    y : 200
}

//Счетчики
var grav = 3.005;
var score = 0;
var foot = 0;
var tmp = 0;
var level = 5;


//позиция дино
var xPos = 0;
var yPos = 570;
var xPos_tmp;
var yPos_tmp;





function draw() {
    
    if(tmp >= 4 && tmp <= 8)
        ctx.drawImage(bg_night, 0, 0);
    else
        ctx.drawImage(bg_day, 0, 0);
    //Респавн кактусов
    for (var i = 0; i < kaktus.length; i++){
        if(tmp >= 4 && tmp <= 8)
            ctx.drawImage(kaktus_night, kaktus[i].x, kaktus[i].y);
        else
            ctx.drawImage(kaktus_day, kaktus[i].x, kaktus[i].y);
        kaktus[i].x -= level;
        
        if (kaktus[i].x == 800)
            kaktus.push({
                x : cvs.width,
                y : 570
            });
        if (xPos + dino_left_day.width >= kaktus[i].x 
            && xPos <= kaktus[i].x + kaktus_day.width 
            && yPos + dino_left_day.height >= kaktus[i].y + kaktus_day.height)
                location.reload();
        //Количество перепрыгнутых кактусов
        if (kaktus[i].x == 20){
            score++;
            tmp++;
        }
        //Смена ног
        foot++;
        if(foot <= 50){
            xPos_tmp = xPos;  
            yPos_tmp = yPos;
            xPos += 15000;
            yPos += 15000;
            if(tmp >= 4 && tmp <= 8)
                ctx.drawImage(dino_right_night, xPos_tmp, yPos_tmp)
            else{
                tmp %= 4;
                ctx.drawImage(dino_right_day, xPos_tmp, yPos_tmp);
            }
            xPos -= 15000;
            yPos -= 15000;
        }
        else if (foot > 50 && foot <= 100){
            xPos_tmp = xPos;  
            yPos_tmp = yPos;
            xPos += 15000;
            yPos += 15000;
            if(tmp >= 4 && tmp <= 8)
                ctx.drawImage(dino_left_night, xPos_tmp, yPos_tmp)
            else{
                tmp %= 4;
                ctx.drawImage(dino_left_day, xPos_tmp, yPos_tmp);
            }
            xPos -= 15000;
            yPos -= 15000;
        }
        else
            foot -= 60;
    }
    //Респавн облаков
    for (var i = 0; i < oblako.length; i++){
        if(tmp >= 4 && tmp <= 8)
            ctx.drawImage(oblako_night, oblako[i].x, oblako[i].y);
        else
            ctx.drawImage(oblako_day, oblako[i].x, oblako[i].y);
        oblako[i].x -= level;
        if (oblako[i].x == 1000)
            oblako.push({
                x : cvs.width,
                y : 220 + Math.floor(Math.random())
            });
    }
    
    //Текущий счет
    if(tmp >= 4 && tmp <= 8)
        ctx.fillStyle = "white";
    else
        ctx.fillStyle = "black";
    ctx.font = "50px Verdana";
    ctx.fillText("Score:" + score, cvs.width - 500, 50)
    
    if (yPos < 570)
        yPos += grav;
    requestAnimationFrame(draw);
}
ttt.onload = draw;